# CG 2022/2023

## Group T06G09

## TP 5 Notes
